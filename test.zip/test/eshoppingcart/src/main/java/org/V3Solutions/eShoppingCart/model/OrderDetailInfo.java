package org.V3Solutions.eShoppingCart.model;

public class OrderDetailInfo {

}
