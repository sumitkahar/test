package org.V3Solutions.eShoppingCart.dao;

import org.V3Solutions.eShoppingCart.entity.Account;

public interface AccountDAO {
 
    
    public Account findAccount(String userName );
    
}