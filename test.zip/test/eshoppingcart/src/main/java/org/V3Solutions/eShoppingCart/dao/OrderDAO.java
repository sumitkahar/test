package org.V3Solutions.eShoppingCart.dao;

import java.util.List;
 
import org.V3Solutions.eShoppingCart.model.CartInfo;
import org.V3Solutions.eShoppingCart.model.OrderDetailInfo;
import org.V3Solutions.eShoppingCart.model.OrderInfo;
import org.V3Solutions.eShoppingCart.model.PaginationResult;
 
public interface OrderDAO {
 
    public void saveOrder(CartInfo cartInfo);
 
    public PaginationResult<OrderInfo> listOrderInfo(int page,
            int maxResult, int maxNavigationPage);
    
    public OrderInfo getOrderInfo(String orderId);
    
    public List<OrderDetailInfo> listOrderDetailInfos(String orderId);
 
}